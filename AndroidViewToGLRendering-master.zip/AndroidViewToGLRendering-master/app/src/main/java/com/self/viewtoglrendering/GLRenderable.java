package com.self.viewtoglrendering;

/**
 * Created by user on 5/4/15.
 */
public interface GLRenderable {

    void setViewToGLRenderer(ViewToGLRenderer viewToGLRenderer);

}
